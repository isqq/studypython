package zzy.demo.myapplication;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.locks.Lock;

public class MainActivity extends AppCompatActivity {

    private String phone = "13488888888";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        test1();

        try {
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
                createFile();
            }
        } catch (IOException e) {
//            System.out.print(e.getLocalizedMessage());
            e.printStackTrace();
        }

        param(1);


        System.out.println(this.phone);


        doSomething();

    }

    private void test1() {
        int target = -5;
        int num = 3;

        target =- num;
        target =+ num;

        System.out.println("target=" + target);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createFile() throws IOException {
        File tempDir;
//        Path path = Files.createTempDirectory("");

        tempDir = File.createTempFile("", ".");
        tempDir.mkdir();
    }

    private void param(int param) {
        if (param == 1) {
            System.out.println("1");
        } else if (param == 2) {
            System.out.println("2");
        } else if (param == 2) {
            System.out.println("3");
        }
    }


    public void doSomething() {
        File f = new File("/sdcard/1");
        f.delete();
    }
}
